<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section-1">
        <div class="container text-center">
            <h1 class="heading-1"> Travel Beautiful Places </h1>
            <h1 class="heading-2"> & Enjoy </h1>
            <p class="para-1"> All The Fantastic Places are here. All The Informations are given of each places.</p>

<?php $__currentLoopData = $posts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row justify-content-center text-center mb-5">
  <?php $__currentLoopData = $productChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4 col-sm-12"> 
                    <div class="card card-product shadow">
                        <div class="img-wrap">    
                        <img src="<?php echo e(URL::asset($product->image)); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <figcaption class="info-wrap mb-3">
                            <h4 class="card-title"> <?php echo e($product->title); ?> </h4>
                            <p class="card-text"> <?php echo e($product->howToGoEng); ?> </p>
                        </figcaption>

                        <a href="<?php echo e('/tourDetails/'.$product->id); ?>" class="btn btn-primary">See Full Details</a>
                    </div>
                    

</div>
                

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views/searchedPlaces.blade.php ENDPATH**/ ?>