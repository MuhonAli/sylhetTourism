<footer class="page-footer font-small blue-grey lighten-5 mb-1 p-5">

    <div class="container text-center text-md-left mt-5">

  
    <div class="row mt-3 dark-grey-text">

   
    <div class="col-md-3 col-lg-4 col-xl-3 mb-1">

   
      <h6 class="text-uppercase font-weight-bold">About Us</h6>
      <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/>
      <p>
        <a to="/"> Click Here </a>
      </p>
      

    </div>
   
    
    <div class="col-md-5 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-1">

    <h5 class="text-uppercase font-weight-bold">Contact Us</h5>
      <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/>

       <h6>Email: Noyeem@gmail.com</h6>
       <h6>Phone: +880111111111</h6> 
    </div>

  </div>

</div>

</footer>
<?php /**PATH C:\wamp\www\sylhetTourism\resources\views/footer.blade.php ENDPATH**/ ?>