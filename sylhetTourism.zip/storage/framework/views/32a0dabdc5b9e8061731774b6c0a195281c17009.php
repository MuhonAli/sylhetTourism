<?php $__env->startSection('title'); ?>
Sylhet Tourism 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section-1">
  <div class="container text-center">
    <h1 class="heading-1"> Travel Beautiful Places </h1><hr><br>

    <?php $__currentLoopData = $places->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placeChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="row justify-content-center text-center mb-5">
      <?php $__currentLoopData = $placeChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 col-sm-12"> 
        <div class="card card-product shadow">
          <div class="img-wrap">    
            <img src="<?php echo e(URL::asset($place->image)); ?>" alt="An Image" class="card-img-top"/>
          </div>
          <figcaption class="info-wrap mb-3">
            <h4 class="card-title"> <?php echo e($place->title); ?> </h4>
            <p class="card-text"> <?php echo e($place->howToGoEng); ?> </p>
          </figcaption>

          <a href="<?php echo e('/placeDetails/'.$place->id); ?>" class="btn btn-primary">See Details</a>
        </div>


      </div>

      <style>
      .display-4{
        margin-top: -27%;
      }
    </style>                

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>
</div>

<div class="col-md-4 offset-4" style="margin-left: 45%;">
  <?php echo e($places->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sylhetTourism\resources\views//places.blade.php ENDPATH**/ ?>