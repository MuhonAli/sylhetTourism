
<div class="sidebar pl-0">
             
             <ul class="nav flex-column text-center" id="border">
              <br/> <br/>
              <li class="nav-item">
                 <a class="nav-link" href="/addPlace">Add New Place</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">Add New Restaurant</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">Add New Hotel</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">All Added Places</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">All Restaurants</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">All Hotels</a>
             </li>
         
             </ul>
</div>
         <?php /**PATH C:\wamp64\www\sylhetTourism\resources\views/admin/adminSidebar.blade.php ENDPATH**/ ?>