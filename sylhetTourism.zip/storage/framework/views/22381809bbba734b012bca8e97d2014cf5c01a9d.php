<?php $__env->startSection('title'); ?>
	Sylhet hrefurism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="sidebar pl-0">
             
             <ul class="nav flex-column text-center" id="border">
             <br/> <br/>
             <li class="nav-item">
                   <a class="nav-link" href="/">Home</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/">All Orders</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/">Add Product</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/">My Products</a>
             </li>

             </ul>
         </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views//user/userSidebar.blade.php ENDPATH**/ ?>