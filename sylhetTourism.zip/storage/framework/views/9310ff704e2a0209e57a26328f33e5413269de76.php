<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div>
        <img src="<?php echo e(URL::asset($product->image)); ?>" class="imageClass"/>
    </div>
    <div class="container mb-5">
        <ul class="nav nav-tabs mt-4" role="tablist">
            <li class="nav-item active">
                <a class="nav-link active" href="#english" role="tab" data-toggle="tab">English</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#bangla" role="tab" data-toggle="tab">বাংলা</a>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content ml-3">
            <div role="tabpanel" class="tab-pane active in mt-3 mb-3" id="english">
                <b>How to go there: </b>
                <br/>
                <?php echo e($product->howToGoEng); ?>

                <br/><br/>
                <b>Where to Stay: </b>
                <p> <?php echo e($product->whereToStayEng); ?> </p>
                <b>Where to Eat: </b>
                <p> <?php echo e($product->whereToEatEng); ?> </p>
            </div>

            <div role="tabpanel" class="tab-pane fade mt-3 mb-3" id="bangla">
                <b> কিভাবে যাবেনঃ </b>
                <br/>
                <?php echo e($product->howToGoBan); ?>

                <br/><br/>
                <b>কোথায় থাকবেনঃ </b>
                <p> <?php echo e($product->whereToStayBan); ?> </p>
                <b>কোথায় খাবেনঃ </b>
                <p> <?php echo e($product->whereToEatBan); ?> </p>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->hasAnyRole('admin')): ?>
                <button class="btn btn-primary"> Edit </button>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="m-5 mb-0"> 
            <div class="media border p-3">
            <i class="fa fa-user mr-2" style="font-size: 38px"></i>
                <div className="media-body">
                    <h4> <?php echo e($comment->name); ?></h4>
                    <p class="ml-3 text-muted"> <?php echo e(date('M j, Y h:ia', strtotime($comment->updated_at))); ?> </p>
                    <p class="ml-3"> <?php echo e($comment->comment); ?> </p>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->id == $comment->user_id): ?>
                    <button type="button" class="btn btn-primary edit" data-toggle="modal" data-target="#myModal" id="<?php echo e($comment->id); ?>">
                        Edit
                    </button>
                    <?php endif; ?>
                    <?php endif; ?>

                    <!-- The Modal -->
                    <div class="modal fade" id="myModal">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                        
                            <!-- Modal Header -->
                            <div class="modal-header">
                            <h4 class="modal-title">Edit your review</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            
                            <!-- Modal body -->
                            <div class="modal-body">
                            <form method="POST" class="ccard card-info" action="<?php echo e('/editedComment'); ?>">
                                <?php echo csrf_field(); ?>
                                    <div class="card-block">
                                        <textarea  class="pb-cmnt-textarea" name="editedComment" id="editedComment">
                                        </textarea>
                                        <input type="hidden" name="comment_id" value="" id="comment_id"/>
                                    </div>
                                    <button class="btn btn-info pull-right mb-2" type="submit">Share</button>
                            </form>
                            </div>
                    
                        </div>
                        </div>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->id == $comment->user_id || Auth::user()->hasAnyRole('admin')): ?>
                    
                    <form action = "<?php echo e('/deleteComment/'.$comment->id); ?>" method = "POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <button class="btn btn-danger" type="submit"> Delete </button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->guard()->check()): ?>
        <form method="POST" class="ccard card-info" action="<?php echo e('/addComment'); ?>">
            <?php echo csrf_field(); ?>
                <div class="card-block">
                    <textarea style="background-color: red" placeholder="Write your comment here!" class="pb-cmnt-textarea" name="comment">
                    </textarea>
                    <input type="hidden" name="post_id" value="<?php echo e($product->id); ?>"/>
                </div>
                <button class="btn btn-info btn-block" type="submit">Share</button>
        </form>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

$(document).on('click', '.edit', function(){

    var id = $(this).attr('id');
    //console.log(id);
    $.ajax({
        method: 'GET',
        url: "/editedComment/"+id,
        dataType: 'json',
        success: function(html){

            console.log(html.data);
            $('#editedComment').val(html.data.comment);
            $('#comment_id').val(html.data.id);
        },
        error: function(jqXHR, textStatus, errorThrown) { // What to do if we fail
        console.log(JSON.stringify(jqXHR));
        console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
    }


    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\noyeemsylhet\sylhetTourism\resources\views//tourDetails.blade.php ENDPATH**/ ?>