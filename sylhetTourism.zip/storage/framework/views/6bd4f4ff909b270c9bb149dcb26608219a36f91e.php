<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="9"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="10"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="11"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="12"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="13"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="14"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="15"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="16"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="17"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="18"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="19"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="20"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="21"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="22"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('Dargah_Gate,_Shah_Jalal_(R)_Majar_Sharif_(3050040910).jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Hazrath Shah Jalal Majar Sharif</h2>
        </div>
      </div>

      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('jaflong cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Jaflong</h2>
        </div>
      </div>

      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Sreemongol Cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Tea Garden Sreemongol</h2>
        </div>
      </div>

      <!-- Slide Four - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('bisnakandi COVER.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Bisnakandi</h2>
          
        </div>
      </div>

      <!-- Slide Five - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Panthumai Cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Panthumai Waterfall</h2>
          
        </div>
      </div>

      <!-- Slide Six - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('ratargul cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Ratargul Swamp Forest</h2>
          
        </div>
      </div>

      <!-- Slide Seven - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('jadukata COVER.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Jadukata River</h2>
          
        </div>
      </div>

      <!-- Slide Eight - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('lalakhal cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Lalakhal</h2>
          
        </div>
      </div>

      <!-- Slide Nine - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('lovachora cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Lovachora</h2>
        </div>
      </div>

      <!-- Slide Ten - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('tangoar haor cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Tangoar Haor</h2>
        </div>
      </div>

    <!-- Slide Eleven - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('lawachera cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Lawachera</h2>
        </div>
      </div>

    <!-- Slide Twelve - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('bulagonj banner.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">White Stone Bulagonj</h2>
        </div>
      </div>

    <!-- Slide Thirteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('sathchori banner.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Sathchori</h2>
        </div>
      </div>
    <!-- Slide Fourteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('madhabkunda.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Madhabkunda Waterfall</h2>
        </div>
      </div>


    <!-- Slide Fifteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('DibirHaor.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Dibir Haor</h2>
        </div>
      </div>

    <!-- Slide Sixteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('bashtola-.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Bashtola Shahid Minar</h2>
        </div>
      </div>

    <!-- Slide Seventeen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('khadimnagar-rainforest cover.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"> Khadimnagar Rainforest </h2>
        </div>
      </div>

    <!-- Slide Eighteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('regent park1.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Regent Park Resort</h2>
        </div>
      </div>
    <!-- Slide Nineteen - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('excelsior-Sylhet-1c.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"> Excelsior Sylhet Resort </h2>
        </div>
      </div>
    
    <!-- Slide Twenty - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('dreamland water park .jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"> Dreamland Water Park </h2>
        </div>
      </div>
    
    <!-- Slide Twenty One - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('Osmani-Museum-Dr.Syed-Zaghlul-Ali31-1024x575.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Osmani Museum</h2>
        </div>
      </div>

    <!-- Slide Twenty Two - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('osmani shishu park.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Osmani Shishu Park</h2>
        </div>
      </div>
    
    <!-- Slide Twenty Three - Set the background image for this slide in the line below -->
    <div class="carousel-item" style="background-image: url('2Keane_Bridge.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Keane Bridge</h2>
        </div>
      </div>


    </div>
    
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
    <div class="section-1">
        <div class="container text-center">
            <h1 class="heading-1"> Travel Beautiful Places </h1>
            <h1 class="heading-2"> & Enjoy </h1>
            <p class="para-1"> All The Fantastic Places are here. All The Informations are given of each places.</p>

<?php $__currentLoopData = $posts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row justify-content-center text-center mb-5">
  <?php $__currentLoopData = $productChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4 col-sm-12"> 
                    <div class="card card-product shadow">
                        <div class="img-wrap">    
                        <img src="<?php echo e(URL::asset($product->image)); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <figcaption class="info-wrap mb-3">
                            <h4 class="card-title"> <?php echo e($product->title); ?> </h4>
                            <p class="card-text"> <?php echo e($product->howToGoEng); ?> </p>
                        </figcaption>

                        <a href="<?php echo e('/tourDetails/'.$product->id); ?>" class="btn btn-primary">See Full Details</a>
                    </div>
                    

</div>
                

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views//index.blade.php ENDPATH**/ ?>