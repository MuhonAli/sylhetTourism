
<div class="sidebar pl-0">
             
    <ul class="nav flex-column text-center" id="border">
     <br/> <br/>
     <li class="nav-item">
        <a class="nav-link" href="/">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/">All Orders</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/">Add Product</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/">My Products</a>
    </li>

    </ul>
</div>
<?php /**PATH C:\wamp64\www\sylhetTourism\resources\views/user/userSidebar.blade.php ENDPATH**/ ?>