<?php $__env->startSection('title'); ?>
  Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="m-5">
        <div class="container shadow" id="addProduct">
          <div class="row">

            <div class="col-md-4">
              <div id="bekaar"> </div>
            </div>
            <div class="col-md-8">
              <form method="POST" action="<?php echo e('/addNewRestaurant'); ?>">
                <?php echo csrf_field(); ?>
                  <h3>Add New Restaurant</h3>
                  <br/>
                  <div class="form-group">
                  <label>Title</label>
                  <input type="text"
                  class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" 
                    id="title" placeholder="Add a Title" name="title" required/>
                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
              
                <div class="form-group">
                  <label>Add an Image File</label>
                  <input type="file"
                  class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>"
                  name="image" id="image" required/>
                  <?php if($errors->has('image')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('image')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                  <label>Email</label>
                  <input type="text"
                  class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                  name="email" id="email" required/>
                  <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                  <label>Contact Number</label>
                  <input type="text"
                  class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>"
                  name="contact" id="contact" required/>
                  <?php if($errors->has('contact')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('contact')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                  <div class="form-group">
                  <label>Description</label>
                  <textarea class="form-control<?php echo e($errors->has('desc') ? ' is-invalid' : ''); ?>"
                   name="desc" id="desc" rows="3" required></textarea>
                    <?php if($errors->has('desc')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('desc')); ?></strong>
                        </span>
                    <?php endif; ?>

                  </div>
                


                <button type="submit" class="btn btn-info">Submit</button>
              </form>
              </div>
              </div>
              </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\sylhetTourism\resources\views//admin/addNewRestaurant.blade.php ENDPATH**/ ?>