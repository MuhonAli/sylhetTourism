<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('minmax_2_7.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"></h2>
        </div>
      </div>

      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Furniture-Background-.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"></h2>
        </div>
      </div>

      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Big-Lots-Dining-Room-Tables-HD-Home-Wallpaper.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"></h2>
        </div>
      </div>

      <!-- Slide Four - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Romantic-Bedroom-Wallpaper-HD-1366x768-5.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4"></h2>
          
        </div>
      </div>

        <!-- Slide Five - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('IMG-4-1024x683.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-5"></h2>
          
        </div>
      </div>

      

    </div>
    
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>


<div class="section-1">
  <div class="container text-center">
    <h1 class="heading-1"> hotels in Sylhet</h1><hr><br>

    <?php $__currentLoopData = $hotels->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="row justify-content-center text-center mb-5">
      <?php $__currentLoopData = $hotelChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 col-sm-12"> 
        <div class="card card-product shadow">
          <div class="img-wrap">    
            <img src="<?php echo e(URL::asset($hotel->image)); ?>" alt="An Image" class="card-img-top"/>
          </div>
          <figcaption class="info-wrap mb-3">
            <h4 class="card-title"> <?php echo e($hotel->title); ?> </h4>
            <p class="card-text"> <?php echo e($hotel->howToGoEng); ?> </p>
          </figcaption>

          <a href="<?php echo e('/tourDetails/'.$hotel->id); ?>" class="btn btn-primary">See Details</a>
        </div>


      </div>

      <style>
      .display-4{
        margin-top: -27%;
      }
    </style>                

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>
</div>

<div class="col-md-4 offset-4" style="margin-left: 45%;">
  <?php echo e($hotels->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sylhetTourism\resources\views//hotels.blade.php ENDPATH**/ ?>