<nav class="navbar navbar-expand-lg navbar-light navBar shadow-sm">
  <a class="navbar-brand" href="/">Sylhet Tourism <span> <i class="fa fa-road" aria-hidden="true"></i></span>
</a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu" aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle Navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  
  <div class="collapse navbar-collapse"></div>
  
  <div class="collapse navbar-collapse" id="navbarMenu">
    <form class="form-inline my-2 my-lg-0 mr-auto" method="POST" action="<?php echo e('/search'); ?>">
      <?php echo csrf_field(); ?>
      <input class="form-control mr-sm-2 roundedBorder" type="search" placeholder="Search" aria-label="Search" name="search">
      <button class="btn btn-outline-info my-2 my-sm-0 roundedBorder" type="submit">Search</button>
    </form>
    <ul class="navbar-nav" style="margin-right: 80px">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Lists
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <li> <a class="nav-link" href="/hotels">Place To Stay</a></li>
          <li> <a class="nav-link" href="/restaurants">Place To Eat</a></li>
          <li class="dropdown-submenu"><a class="nav-link dropdown-item dropdown-toggle" href="#">Place To Visit</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="/tourDetails/1">Bisnakandi</a></li>
              <li><a class="dropdown-item" href="/tourDetails/2">Jaflong</a></li>
              <li><a class="dropdown-item" href="#">Jadukata River</a></li>
              <li><a class="dropdown-item" href="#">Hajrath Shah jalal Majar Sharif</a></li>
            </ul>
          </li>
        </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/">Home</a>
        </li>
      <?php if(auth()->guard()->guest()): ?>
      <li class="nav-item">
        <a class="nav-link" href="/register">Register</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/login">Login</a>
      </li>
      <?php else: ?>
      <li>
        <a class="nav-link" href="/home">
          <?php echo e(Auth::user()->name); ?>  
        </a>
      </li>
      <li>
          <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
          </form>
      </li>
                          
      <?php endif; ?>

      
    </ul>
    
  </div>
  
</nav><?php /**PATH C:\wamp\www\sylhetTourism\resources\views/partial/navbar.blade.php ENDPATH**/ ?>