<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div>
        <img src="<?php echo e(URL::asset('/css/images/blog-2.jpg')); ?>" class="imageClass"/>
    </div>
    <div class="container mb-5">
        <ul class="nav nav-tabs mt-4" role="tablist">
            <li class="nav-item active">
                <a class="nav-link active" href="#english" role="tab" data-toggle="tab">English</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#bangla" role="tab" data-toggle="tab">বাংলা</a>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content ml-3">
            <div role="tabpanel" class="tab-pane active in mt-3 mb-3" id="english">
                Despite the loss of its former splendour due to unrestricted mining and crushing of stones, Jaflong is still a ‘must-see’ destination for tourists visiting Sylhet. Flowing from the north Khasi mountains, the river Dauki enters Bangladesh under the name ‘Piyain’, along the bank of which lies the spectacular Jaflong. About 62 km north-east from Sylhet city, Jaflong is in the East Jaflong Union under Guainghat Upazilla. Visitors can hire boats to go to the Zero Point and see the beautiful hanging bridge over the Dauki. Just across the river on the western side are the villages Sangrampunji and Nakshiapunji, which are accessible through ferries or rented boats. Just beside Nakshiapunji is Jaflong Tea Garden which is a top tourist attraction.
            </div>
            <div role="tabpanel" class="tab-pane fade mt-3 mb-3" id="bangla">
                অনিয়ন্ত্রিত পাথর উত্তোলন ও পাথরভাঙ্গা ( ক্রাশার) মেশিনের উৎপাতে আগের সেই সৌন্দর্য্য অবশিষ্ট না থাকলে ও এখনো সিলেটে বেড়াতে আসা পর্যটকদের কাছে জাফলং ‘মাস্ট সি’ গন্তব্য। উত্তর খাসিয়া হিলস থেকে নেমে আসা ডাউকী নদী বাংলাদেশে প্রবেশ করেছে পিয়াইন নাম নিয়ে, এই পিয়াইন নদীর অববাহিকাতেই জাফলং- সিলেট জেলার গোয়াইনঘাট উপজেলার পূর্ব জাফলং ইউনিয়নে। সিলেট শহর থেকে ৬২ কিমি উত্তর-পূর্বে এর অবস্থান, গাড়ী থেকে নেমে ভাড়ার নৌকা নিয়ে জিরোপয়েন্টে যাওয়া যায়, যেখানে রয়েছে ডাউকি’র ঝুলন্ত সেতু। খেয়া বা ভাড়া নৌকায় নদী পেরিয়ে পশ্চিম তীরে গেলে খাসিয়া আদিবাসীদের গ্রাম সংগ্রামপুঞ্জি ও নকশীয়াপুঞ্জি। নদীর পাড় থেকে স্থানীয় বাহনযোগে এসব পুঞ্জী ঘুরে বেড়ানো যায়। নকশীয়াপুঞ্জির পাশেই জাফলং চা বাগান। কোন কোন পর্যটক চা বাগানে ঘুরে বেড়াতে ও পছন্দ করেন। 
            </div>
        </div>

        <div class="ccard card-info ml-3">
                <div class="card-block">
                    
                </div>
                <div class="card-block">
                    <textarea placeholder="Write your comment here!" class="pb-cmnt-textarea" value="">
                    </textarea>
                </div>
            <button class="btn btn-info btn-block" type="button">Share</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views//TourDetails.blade.php ENDPATH**/ ?>