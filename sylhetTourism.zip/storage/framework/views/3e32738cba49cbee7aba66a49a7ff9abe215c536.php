<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('rice.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Chicken Biriyani</h2>
        </div>
      </div>

      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('439410.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Spicy Chicken Fry</h2>
        </div>
      </div>

      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('Pizza_Pics13.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">PIZZA</h2>
        </div>
      </div>

      <!-- Slide Four - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('1.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Csirkes Saslik</h2>
          
        </div>
      </div>
      <!-- Slide Five - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('burger.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-5">HOT SBURGER</h2>
          
        </div>
      </div>
      <!-- Slide six - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('sorma.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-6">Chicken Shawarma</h2>
          
        </div>
      </div>
      <!-- Slide seven - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('DSC_0038.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-7">VEGETABLE CHOW-MEIN</h2>
          
        </div>
      </div>
      <!-- Slide eight - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('210878.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-8">LAZANIA</h2>
          
        </div>
      </div>




      

    </div>
    
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
    <div class="section-1">
        <div class="container text-center">
            <h1 class="heading-1"> Restautants in Sylhet </h1>

            <p class="para-1"> We Are here to make your tour Beautiful. </p>
            

            <div class="row justify-content-center text-center"> 
                <div class="col-md-4 col-sm-12"> 
                    <div class="card card-product shadow">
                        <div class="img-wrap">    
                        <img src="<?php echo e(URL::asset('/css/images/blog-2.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>.
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>

                </div>
                
                <div class="col-md-4 col-sm-12"> 
                <div class="card card-product shadow">
                        <div class="img-wrap">
                            <img src="<?php echo e(URL::asset('/css/images/back2.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12"> 
                <div class="card card-product shadow">
                        <div class="img-wrap">        
                            <img src="<?php echo e(URL::asset('/css/images/Back1.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\sylhetTourism\resources\views//restaurants.blade.php ENDPATH**/ ?>