<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


        <p><?php echo e($posts->title); ?></p>

    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views/searchedplaces.blade.php ENDPATH**/ ?>