<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="m-5">
        <div class="container shadow" id="addProduct">
          <div class="row">

            <div class="col-md-4">
              <div id="bekaar"> </div>
            </div>
            <div class="col-md-8">
              <form method="POST" action="<?php echo e('/addNewPlace'); ?>">
                <?php echo csrf_field(); ?>
                  <h3>Add New Place</h3>
                  <br/>
                  <div class="form-group">
                  <label>Title</label>
                  <input type="text"
                  class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" 
                    id="title" placeholder="Add a Title" name="title" required/>
                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
              
                <div class="form-group">
                  <label>Add an Image File</label>
                  <input type="file"
                  class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>"
                  name="image" id="image" required/>
                  <?php if($errors->has('image')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('image')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                <label>How to go there (English) </label>
                <textarea class="form-control<?php echo e($errors->has('howToGoEng') ? ' is-invalid' : ''); ?>"
                   name="howToGoEng" id="howToGoEng" rows="3" required></textarea>
                  <?php if($errors->has('howToGoEng')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('howToGoEng')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                <label>Where To Stay (English) </label>
                <textarea class="form-control<?php echo e($errors->has('whereToStayEng') ? ' is-invalid' : ''); ?>"
                   name="whereToStayEng" id="whereToStayEng" rows="3" required></textarea>
                  <?php if($errors->has('whereToStayEng')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('whereToStayEng')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                <label>Where To Eat (English) </label>
                <textarea class="form-control<?php echo e($errors->has('whereToEatEng') ? ' is-invalid' : ''); ?>"
                   name="whereToEatEng" id="whereToEatEng" rows="3" required></textarea>
                  <?php if($errors->has('whereToEatEng')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('whereToEatEng')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                
                <div class="form-group">
                <label>How to go there (Bangla) </label>
                <textarea class="form-control<?php echo e($errors->has('howToGoBan') ? ' is-invalid' : ''); ?>"
                   name="howToGoBan" id="howToGoBan" rows="3" required></textarea>
                  <?php if($errors->has('howToGoBan')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('howToGoBan')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                <label>Where To Stay (Bangla) </label>
                <textarea class="form-control<?php echo e($errors->has('whereToStayBan') ? ' is-invalid' : ''); ?>"
                   name="whereToStayBan" id="whereToStayBan" rows="3" required></textarea>
                  <?php if($errors->has('whereToStayBan')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('whereToStayBan')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                <label>Where To Eat (Bangla) </label>
                <textarea class="form-control<?php echo e($errors->has('whereToEatBan') ? ' is-invalid' : ''); ?>"
                   name="whereToEatBan" id="whereToEatBan" rows="3" required></textarea>
                  <?php if($errors->has('whereToEatBan')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('whereToEatBan')); ?></strong>
                        </span>
                  <?php endif; ?>
                </div>


                <button type="submit" class="btn btn-info">Submit</button>
              </form>
              </div>
              </div>
              </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\sylhetTourism\resources\views//admin/addNewPlace.blade.php ENDPATH**/ ?>