<?php $__env->startSection('content'); ?>



<div class="container-fluid p-0" id="main">

<?php if(Auth::user()->hasAnyRole('admin')): ?>      
    <?php echo $__env->make('admin.adminSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row mediaMargin">
  <div class="col-sm-12 mt-5">
    <h3>User Profile</h3>
        <div class="table-responsive">
            <table class="table table-striped">
                <tbody>
                    
                <tr>
                        
                  <th>Name</th>
                  <td><?php echo e(Auth::user()->name); ?></td>    
                        
                </tr>

                <tr>
                        
                  <th>Email</th>
                  <td><?php echo e(Auth::user()->email); ?></td>    
                              
                </tr>
                      

                </tbody>
            </table>
        </div>
    </div>

</div>


<hr/>



<?php else: ?>
    <div class="row justify-content-center mt-5">
        <div>
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\noyeemsylhet\sylhetTourism\resources\views/home.blade.php ENDPATH**/ ?>