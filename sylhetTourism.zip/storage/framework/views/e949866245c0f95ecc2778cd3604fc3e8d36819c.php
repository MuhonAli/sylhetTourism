<?php $__env->startSection('title'); ?>
	Sylhet Tourism
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-1">
        <div class="container text-center">
            <h1 class="heading-1"> Hotels in Sylhet </h1>

            <p class="para-1"> We Are here to make your tour Beautiful. </p>
            

            <div class="row justify-content-center text-center"> 
                <div class="col-md-4 col-sm-12"> 
                    <div class="card card-product shadow">
                        <div class="img-wrap">    
                        <img src="<?php echo e(URL::asset('/css/images/blog-2.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>.
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>

                </div>
                
                <div class="col-md-4 col-sm-12"> 
                <div class="card card-product shadow">
                        <div class="img-wrap">
                            <img src="<?php echo e(URL::asset('/css/images/back2.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12"> 
                <div class="card card-product shadow">
                        <div class="img-wrap">        
                            <img src="<?php echo e(URL::asset('/css/images/Back1.jpg')); ?>" alt="An Image" class="card-img-top"/>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title"> Respnsive </h4>
                            <p class="card-text"> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
                            <a href="#" class="btn btn-primary">See Full Details</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sylhetTourism\resources\views//hotels.blade.php ENDPATH**/ ?>