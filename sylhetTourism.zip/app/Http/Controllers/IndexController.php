<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Place;
use App\Restaurant;
use App\Hotel;
use App\Comment;
use Redirect;
use Auth;

class IndexController extends Controller
{
    public function index()
    {
        $places = Place::orderBy('id', 'desc')->take(6)->get();
        $restaurants = Restaurant::orderBy('id', 'desc')->take(3)->get();
        $hotels = Hotel::orderBy('id', 'desc')->take(3)->get();
        return view('/index',compact('places', 'restaurants', 'hotels'));
    }
    public function placeDetails($id)
    {
        $product = Place::find($id);
        $comments = Comment::where('post_id', $id)->get();
        return view('/placeDetails',compact('product', 'comments'));
    }

    public function addComment(Request $request)
    {
        $this->validate($request,[
        	'comment'=>'required',
            'post_id'=>'required'
           ]);
        
        $post = new Comment;
        $post->comment = $request->input('comment');
        $post->post_id = $request->input('post_id');
        $post->name = Auth::user()->name;
        $post->user_id = Auth::user()->id;
        $post->save();
        

       // Session::flash('comments', 'Thanks for your feedback!');

        return Redirect::back()->withErrors(['msg', 'The Message']);
        //redirect($_SERVER['HTTP_REFERER']);
        
    }
    public function getSearchedPlace(Request $request)
    {   
        $search = ucfirst($request->search);
        $posts = Place::where('title','like',$search.'%')->orderBy('id')->get();
        //dd(gettype($posts));
        //dd($posts);
    	if(count($posts)>0)
    	return view('searchedPlaces',['posts' => $posts]);
   
    	//return redirect('/')->with('message','Not Found');
    }
    
    public function places()
    {
        $places = Place::orderBy('id', 'desc')->paginate(3);
        return view('/places',compact('places'));
    }


    public function restaurants()
    {
        $restaurants = Restaurant::orderBy('id', 'desc')->paginate(9);
        return view('/restaurants',compact('restaurants'));
    }

    public function hotels()
    {
        $hotels = Hotel::orderBy('id', 'desc')->paginate(9);
        return view('/hotels',compact('hotels'));
    }


}

