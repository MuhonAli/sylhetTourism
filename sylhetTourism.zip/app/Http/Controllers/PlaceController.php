<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Place;
use App\Hotel;
use App\Restaurant;

class PlaceController extends Controller
{
    public function addPlace(Request $request)
    {
        $this->validate($request,[
        	'title'=>'required',
            'howToGoEng'=>'required',
            'whereToStayEng'=> 'required',
            'whereToEatEng'=> 'required',
            'howToGoBan'=> 'required',
            'whereToStayBan'=> 'required',
            'whereToEatBan'=> 'required',
        	'image'=>'required'
           ]);
        	
            
        $post = new Place;
        $post->title = $request->input('title');
        $post->howToGoEng = $request->input('howToGoEng');
        $post->whereToStayEng = $request->input('whereToStayEng');
        $post->whereToEatEng = $request->input('whereToEatEng');
        $post->howToGoBan = $request->input('howToGoBan');
        $post->whereToStayBan = $request->input('whereToStayBan');
        $post->whereToEatBan = $request->input('whereToEatBan');
        $post->image = $request->input('image');

        $post->save();
        
        return "Done!!";
    }
    
    public function updatePlace(Request $request)
    {
        dd($request->title, $request->desc);
    }

    public function addHotel(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
            'image'=>'required',
            'email'=> 'required',
            'contact'=> 'required',
            'desc'=> 'required'
           ]);
            
            
        $post = new Hotel;
        $post->title = $request->input('title');
        $post->image = $request->input('image');
        $post->email = $request->input('email');
        $post->contact = $request->input('contact');
        $post->desc = $request->input('desc');

        $post->save();
        
        return "Done!!";
    }

    public function addRestaurant(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
            'image'=>'required',
            'email'=> 'required',
            'contact'=> 'required',
            'desc'=> 'required'
           ]);
            
            
        $post = new Restaurant;
        $post->title = $request->input('title');
        $post->image = $request->input('image');
        $post->email = $request->input('email');
        $post->contact = $request->input('contact');
        $post->desc = $request->input('desc');

        $post->save();
        
        return "Done!!";
    }

    public function showHotels()
    {
        return view('/hotels');
    }


    public function allAddedPlace()
    {
        $posts = Place::all();
        return view('/allAddedPlace',compact('posts'));
    }
}
