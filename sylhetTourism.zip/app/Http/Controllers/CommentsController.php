<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;

class CommentsController extends Controller
{

    public function getComment($id)
    {
        $data = Comment::find($id);
        return response()->json(['data' => $data]);
    }

    public function deleteComment($id)
    {
        $comment = Comment::find($id);
        $comment->delete();
        return redirect('/');
    }
    public function editComment(Request $request)
    {
        $comment = Comment::find($request->comment_id);
        $this->validate($request,[
        	'editedComment'=>'required'
           ]);
        $comment->comment = $request->input('editedComment');
        $comment->save();
        return redirect('/');
        
    }
}
