<footer class="page-footer font-small blue-grey lighten-5 mb-1 p-5">

    <div class="container text-center text-md-left mt-5">

  
    <div class="row mt-3 dark-grey-text">

   
    <div class="col-md-4 col-lg-4 col-xl-3 mb-1">

   
      <h6 class="text-uppercase font-weight-bold text-center">About Us</h6>
      <center><hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/></center>
      <p style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's </p>
      

    </div>
   
   
    <div class="col-md-4 col-lg-4 col-xl-3 mb-1 text-center">
      <h6 class="text-uppercase font-weight-bold text-center">Quick Links</h6>
      <center><hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/></center>
      <p><a to="/"> Places </a></p>
      <p><a to="/"> Hotels </a></p>
      <p><a to="/"> Restaurents </a></p>

    </div>
   

    <div class="col-md-4 col-lg-4 col-xl-3 mb-1 text-center">
      <h6 class="text-uppercase font-weight-bold text-center">Account</h6>
      <center><hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/></center>
      <p><a to="/"> Register </a></p>
      <p><a to="/"> Login </a></p>
      <p><a to="/"> Profile </a></p>

    </div>
   
    <div class="col-md-5 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-1 text-center">
      <h6 class="text-uppercase font-weight-bold text-center">Contact Us</h6>
      <center><hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto underline"/></center>
       <h6>Email: Noyeem@gmail.com</h6>
       <h6>Phone: +880111111111</h6> 
    </div>

  </div>

</div>

</footer>
