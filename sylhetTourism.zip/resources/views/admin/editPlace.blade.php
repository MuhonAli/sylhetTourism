@extends('layouts.master')

@section('title')
	Sylhet Tourism
@endsection

@section('content')

<div class="m-5">
        <form method="POST" action="{{ '/updatePlace' }}">
        @csrf

        <div class="form-group">
                  <label>Title</label>
                  <input type="text"
                  class="form-control{{ $errors->has('title') ? ' is-invalid' : '' }}" 
                    id="title" placeholder="Add a Title" name="title" required/>
                    @if ($errors->has('title'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('title') }}</strong>
                        </span>
                    @endif
                  </div>
                  
                <div class="form-group">
                <label>Description</label>
                <textarea class="form-control{{ $errors->has('desc') ? ' is-invalid' : '' }}"
                   name="desc" id="desc" rows="3" required></textarea>
                  @if ($errors->has('desc'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('desc') }}</strong>
                        </span>
                  @endif
                </div>

         <button type="submit" class="btn btn-info">Submit</button>
        </form>
        </div>
@endsection