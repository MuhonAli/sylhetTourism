@extends('layouts.master')

@section('title')
	Sylhet Tourism
@endsection

@section('content')

<div class="m-5">
        <div class="container shadow" id="addProduct">
          <div class="row">

            <div class="col-md-4">
              <div id="bekaar"> </div>
            </div>
            <div class="col-md-8">
              <form method="POST" action="{{'/addNewHotel'}}">
                @csrf
                  <h3>Add New Hotel</h3>
                  <br/>
                  <div class="form-group">
                  <label>Title</label>
                  <input type="text"
                  class="form-control{{ $errors->has('title') ? ' is-invalid' : '' }}" 
                    id="title" placeholder="Add a Title" name="title" required/>
                    @if ($errors->has('title'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('title') }}</strong>
                        </span>
                    @endif
                  </div>
              
                <div class="form-group">
                  <label>Add an Image File</label>
                  <input type="file"
                  class="form-control{{ $errors->has('image') ? ' is-invalid' : '' }}"
                  name="image" id="image" required/>
                  @if ($errors->has('image'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('image') }}</strong>
                        </span>
                  @endif
                </div>

                <div class="form-group">
                  <label>Email</label>
                  <input type="text"
                  class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
                  name="email" id="email" required/>
                  @if ($errors->has('email'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                  @endif
                </div>

                <div class="form-group">
                  <label>Contact Number</label>
                  <input type="text"
                  class="form-control{{ $errors->has('contact') ? ' is-invalid' : '' }}"
                  name="contact" id="contact" required/>
                  @if ($errors->has('contact'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('contact') }}</strong>
                        </span>
                  @endif
                </div>

                  <div class="form-group">
                  <label>Description</label>
                  <textarea class="form-control{{ $errors->has('desc') ? ' is-invalid' : '' }}"
                   name="desc" id="desc" rows="3" required></textarea>
                    @if ($errors->has('desc'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('desc') }}</strong>
                        </span>
                    @endif

                  </div>
                


                <button type="submit" class="btn btn-info">Submit</button>
              </form>
              </div>
              </div>
              </div>
    </div>

@endsection