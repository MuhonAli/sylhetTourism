
<div class="sidebar pl-0">
             <br/> <br/>
             <ul class="nav flex-column text-center" id="border">
              <li class="nav-item">
                 <a class="nav-link" href="/addNewPlace">Add New Place</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/addNewRestaurant">Add New Restaurant</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/addNewHotel">Add New Hotel</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="/allAddedPlace">All Added Places</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">All Restaurants</a>
             </li>
             <li class="nav-item">
                 <a class="nav-link" href="#">All Hotels</a>
             </li>
         
             </ul>
</div>
         