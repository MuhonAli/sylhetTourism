@extends('layouts.master')

@section('title')
Sylhet Tourism 
@endsection

@section('content')

<div class="section-1">
  <div class="container text-center">
    <h1 class="heading-1"> Travel Beautiful Places </h1><hr><br>

    @foreach($places->chunk(3) as $placeChunk)

    <div class="row justify-content-center text-center mb-5">
      @foreach($placeChunk as $place)
      <div class="col-md-4 col-sm-12"> 
        <div class="card card-product shadow">
          <div class="img-wrap">    
            <img src="{{URL::asset($place->image)}}" alt="An Image" class="card-img-top"/>
          </div>
          <figcaption class="info-wrap mb-3">
            <h4 class="card-title"> {{ $place->title }} </h4>
            <p class="card-text"> {{ $place->howToGoEng }} </p>
          </figcaption>

          <a href="{{'/placeDetails/'.$place->id}}" class="btn btn-primary">See Details</a>
        </div>


      </div>

      <style>
      .display-4{
        margin-top: -27%;
      }
    </style>                

    @endforeach    
  </div>
  @endforeach
  
</div>
</div>

<div class="col-md-4 offset-4" style="margin-left: 45%;">
  {{ $places->links() }}
</div>
@endsection
@section('footer')

@include('footer')

@endsection
