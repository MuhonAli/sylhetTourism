<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', function () {
    return view('welcome');
});  

Route::get('/', 'IndexController@index');

Route::get('/placeDetails/{id}','IndexController@placeDetails');

Route::get('/hotels', 'IndexController@hotels');
Route::get('/places', 'IndexController@places');
Route::get('/restaurants', 'IndexController@restaurants');
Route::get('/allAddedPlace', 'PlaceController@allAddedPlace');


Route::POST('/search', 'IndexController@getSearchedPlace');



Auth::routes(['verify'=> true]);                 

Route::POST('/addComment', 'IndexController@addComment')->middleware(['auth']);
Route::DELETE('/deleteComment/{id}','CommentsController@deleteComment')->middleware(['auth']);
Route::POST('/editedComment','CommentsController@editComment')->middleware(['auth']);
Route::GET('/editedComment/{id}','CommentsController@getComment')->middleware(['auth']);



Route::get('/home', 'HomeController@index')->name('home')->middleware(['auth']);


Route::get('/admin', function(){

    return "You are an admin";
    
})->middleware(['auth', 'auth.admin']);

Route::get('/addNewPlace', function () {
    return view('/admin.addNewPlace');
})->middleware(['auth', 'auth.admin']);

Route::get('/addNewRestaurant', function () {
    return view('/admin.addNewRestaurant');
})->middleware(['auth', 'auth.admin']);

Route::get('/addNewHotel', function () {
    return view('/admin.addNewHotel');
})->middleware(['auth', 'auth.admin']);



Route::get('/editPlace', function () {
    return view('/admin.editPlace');
})->middleware(['auth', 'auth.admin']);

Route::POST('/updatePlace','PlaceController@updatePlace')->middleware(['auth', 'auth.admin']);
Route::POST('/addNewPlace','PlaceController@addPlace')->middleware(['auth', 'auth.admin']);
Route::POST('/addNewRestaurant','PlaceController@addRestaurant')->middleware(['auth', 'auth.admin']);
Route::POST('/addNewHotel','PlaceController@addHotel')->middleware(['auth', 'auth.admin']);
